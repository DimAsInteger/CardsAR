module.exports = {
    facebook: {
        clientID: '2061295350765742',
        clientSecret: '33c9bb8efe922c5718ba06132406f650'
    },
    
    google: {
        clientID: '1040445849965-1lgu8m9bk6ffvuga1vugqmvd4jsmc3di.apps.googleusercontent.com',
        clientSecret: 'hcr8O99WWY5DYT-Nm3Araz2Q'
    }
}